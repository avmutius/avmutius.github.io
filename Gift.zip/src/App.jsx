import "./App.css";
import { Canvas } from "@react-three/fiber";
import { KeyboardControls, OrbitControls, Sky, Stats } from "@react-three/drei";
import Grass from "./Grass";
import { Suspense } from "react";
import { Physics } from "@react-three/rapier";
import Ecctrl from "ecctrl";
import CharacterModel from "./CharacterModel.jsx";
import {
	Bloom,
	DepthOfField,
	EffectComposer,
	Noise,
	Sepia,
	ToneMapping,
	Vignette,
} from "@react-three/postprocessing";

const keyboardMap = [
	{ name: "forward", keys: ["ArrowUp", "KeyW"] },
	{ name: "backward", keys: ["ArrowDown", "KeyS"] },
	{ name: "leftward", keys: ["ArrowLeft", "KeyA"] },
	{ name: "rightward", keys: ["ArrowRight", "KeyD"] },
	{ name: "jump", keys: ["Space"] },
	{ name: "run", keys: ["Shift"] },
];

function App() {
	return (
		<div
			style={{
				height: "100vh",
				width: "100vw",
				position: "absolute",
				left: 0,
				top: 0,
			}}
		>
			<Canvas camera={{ position: [0, 0, 0], fov: 60 }}>
				<EffectComposer>
					<Bloom
						luminanceThreshold={0.8}
						luminanceSmoothing={0.9}
						height={300}
					/>
				</EffectComposer>
				<Sky
					turbidity={8}
					rayleigh={0.8}
					mieCoefficient={0.01}
					mieDirectionalG={0.8}
					sunPosition={[1, 0.3, 0]}
				/>
				<ambientLight />
				<Physics timeStep="vary">
					<Grass />
					<KeyboardControls map={keyboardMap}>
						<Ecctrl
							camInitDis={-30}
							camMinDis={-10}
							camMaxDis={-50}
						>
							<CharacterModel />
						</Ecctrl>
					</KeyboardControls>
				</Physics>
				<Stats />
			</Canvas>
		</div>
	);
}

export default App;
